import { createFileRoute, useSearch } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { PuzzleBoard } from "@/components/PuzzleBoard";
import { GlimpsePlayer } from "@/components/GlimpsePlayer";
import { layoutPhrase, type Cell } from "@/lib/puzzle";
import type { GameState } from "@/lib/game-state";
import { PHASE_DURATIONS } from "@/lib/game-state";
import { fetchGameState as fetchGameStateAction } from "@/lib/game-actions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/stage")({
  validateSearch: (search: Record<string, unknown>) => ({
    table: typeof search.table === "string" ? search.table : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Glimpse Stage View" },
      {
        name: "description",
        content: "Stage view for casting or OBS - shows clip, scores, and title reveal",
      },
    ],
  }),
  component: StageView,
});

function StageView() {
  const { table: tableId } = useSearch({ from: "/stage" });
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [revealed, setRevealed] = useState<Set<string>>(new Set());
  const [delays, setDelays] = useState<Record<string, number>>({});
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const pollInterval = useRef<number | null>(null);

  const currentClip = gameState?.currentClipId
    ? gameState.library.clips.find((c) => c.id === gameState.currentClipId)
    : null;

  const rows: Cell[][] = useMemo(
    () => (currentClip ? layoutPhrase(currentClip.title) : []),
    [currentClip],
  );
  
  // Calculate time remaining in current phase
  useEffect(() => {
    // Use routine deadline if routine is running, otherwise fall back to manual phase deadline
    const deadline = gameState?.routine?.status === "running" 
      ? gameState.routine.phaseDeadline 
      : gameState?.phaseDeadline;
      
    if (!deadline || gameState?.sessionPaused) {
      setTimeRemaining(null);
      return;
    }
    
    const updateTimer = () => {
      const now = Date.now();
      const remaining = Math.max(0, deadline - now);
      setTimeRemaining(remaining);
    };
    
    updateTimer();
    const timer = window.setInterval(updateTimer, 100);
    
    return () => clearInterval(timer);
  }, [gameState?.phaseDeadline, gameState?.routine?.phaseDeadline, gameState?.routine?.status, gameState?.sessionPaused]);

  const fetchGameState = useCallback(async () => {
    if (!tableId) return;
    try {
      const normalizedId = tableId.toUpperCase();
      const data = await fetchGameStateAction({ data: normalizedId });
      setGameState(data.table);
    } catch (error) {
      console.error("Failed to fetch game state:", error);
    }
  }, [tableId]);

  // Auto-reveal: hint reveals during play, full reveal at end
  useEffect(() => {
    if (gameState?.phase === "reveal" && gameState.revealedTitle && currentClip) {
      // Full reveal with animation
      const ids: string[] = [];
      rows.forEach((row, r) =>
        row.forEach((cell, c) => {
          if (cell.kind === "letter") ids.push(`${r}-${c}`);
        }),
      );
      const nextDelays: Record<string, number> = {};
      ids.forEach((id, i) => (nextDelays[id] = i * 110));
      setDelays(nextDelays);
      setRevealed(new Set(ids));
    } else if (gameState?.phase === "playing" || gameState?.phase === "guessing" || gameState?.phase === "judging") {
      // Show hint reveals without animation
      setRevealed(new Set(gameState?.hintRevealedPositions ?? []));
      setDelays({});
    } else {
      setRevealed(new Set());
      setDelays({});
    }
  }, [gameState?.phase, gameState?.revealedTitle, gameState?.hintRevealedPositions, currentClip, rows]);

  useEffect(() => {
    if (tableId) {
      fetchGameState();
      pollInterval.current = window.setInterval(fetchGameState, 1000);
      return () => {
        if (pollInterval.current) clearInterval(pollInterval.current);
      };
    }
  }, [tableId, fetchGameState]);

  if (!tableId) {
    return (
      <main className="stage-bg min-h-screen font-body text-white/90 flex items-center justify-center">
        <div className="text-center">
          <div className="marquee-lights mx-auto mb-4 h-1.5 w-40 rounded-full" />
          <h1 className="text-gold-gradient font-display text-6xl tracking-[0.12em] sm:text-8xl">
            GLIMPSE
          </h1>
          <p className="mt-4 text-white/60 uppercase tracking-wider text-sm">
            Stage View — No table code provided
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="stage-bg min-h-screen font-body text-white/90">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-6">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="marquee-lights h-1 w-24 rounded-full" />
            <h1 className="text-gold-gradient font-display text-4xl tracking-[0.12em] sm:text-6xl">
              GLIMPSE
            </h1>
            {gameState?.sessionPaused && (
              <div className="rounded-full border-2 border-gold bg-gold/20 px-5 py-2 font-display text-2xl tracking-wider text-gold uppercase animate-pulse">
                PAUSED
              </div>
            )}
          </div>
          <div className="text-right">
            <p className="text-xs text-white/40 uppercase tracking-wider">Table</p>
            <p className="font-display text-3xl text-gold tracking-widest">{tableId}</p>
          </div>
        </header>

        {/* Phase Countdown Warning */}
        {timeRemaining !== null && timeRemaining <= 10000 && (
          <div
            className={cn(
              "rounded-xl border-2 px-8 py-4 font-display text-center uppercase tracking-wider transition-all",
              timeRemaining <= 5000
                ? "border-red-500 bg-red-500/20 text-red-300 animate-pulse"
                : "border-gold bg-gold/20 text-gold"
            )}
          >
            <span className="text-3xl font-bold">
              {timeRemaining <= 5000 ? "⚠️ " : ""}
              {Math.ceil(timeRemaining / 1000)}s remaining
              {timeRemaining <= 5000 ? " ⚠️" : ""}
            </span>
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-[1fr,380px]">
          <div className="space-y-6">
            {gameState?.phase === "reveal" && currentClip && (
              <div className="space-y-4">
                <PuzzleBoard rows={rows} revealed={revealed} delays={delays} />
                <div className="text-center">
                  <span className="rounded-full border border-gold/40 bg-black/30 px-6 py-2.5 font-display text-2xl tracking-[0.25em] text-gold uppercase">
                    {currentClip.category} · {currentClip.type}
                  </span>
                </div>
              </div>
            )}

            {/* Show hint reveals during gameplay if any letters revealed */}
            {gameState?.phase !== "reveal" && currentClip && gameState.hintRevealedPositions.length > 0 && (
              <div className="space-y-2">
                <PuzzleBoard rows={rows} revealed={revealed} delays={delays} />
                <div className="text-center text-sm text-gold/70 font-display uppercase tracking-wider">
                  {gameState.hintRevealedPositions.length} hint{gameState.hintRevealedPositions.length !== 1 ? 's' : ''} revealed
                </div>
              </div>
            )}

            {gameState?.currentClipId &&
              currentClip &&
              gameState.phase !== "reveal" && (() => {
                const clipMetadata = currentClip.metadata;
                const isYouTubeClip = clipMetadata && "youtubeId" in clipMetadata;
                const isUploadClip = clipMetadata && "fileName" in clipMetadata;
                const youtubeId = isYouTubeClip ? clipMetadata.youtubeId : undefined;
                const videoUrl = isUploadClip ? currentClip.source.id : undefined;
                const timeStart = clipMetadata?.timeStart ?? 0;
                const timeEnd = clipMetadata?.timeEnd;
                
                return (
                  <div className="board-frame aspect-video relative">
                    <GlimpsePlayer
                      youtubeId={youtubeId}
                      videoUrl={videoUrl}
                      playing={gameState.clipPlaying}
                      positionSec={gameState.clipPosition}
                      isController={false}
                      timeStart={timeStart}
                      timeEnd={timeEnd}
                    />
                  </div>
                );
              })()}

            {gameState?.phase === "lobby" && (
              <div className="board-frame flex items-center justify-center py-20">
                <div className="text-center">
                  <div className="marquee-lights mx-auto mb-6 h-2 w-40 rounded-full" />
                  <p className="text-white/60 uppercase tracking-[0.3em] text-xl">
                    Waiting for round to start...
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="rounded-xl border border-white/10 bg-black/25 p-6 space-y-4">
            <h3 className="font-display text-2xl text-gold uppercase tracking-wider border-b border-white/10 pb-3">
              Players
            </h3>
            <div className="space-y-3">
              {gameState?.players.map((p) => (
                <div
                  key={p.id}
                  className={cn(
                    "rounded-lg border px-4 py-3 transition-all",
                    p.lockedIn
                      ? "border-gold/40 bg-gold/10"
                      : "border-white/5 bg-white/5",
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white text-lg flex items-center gap-2 flex-wrap">
                        <span>{p.name}</span>
                        {p.isHost && (
                          <span className="text-xs rounded-full border border-gold/40 bg-gold/20 px-2 py-0.5 text-gold uppercase tracking-wider">
                            Host
                          </span>
                        )}
                        {p.lockedIn && (
                          <span className="text-xs rounded-full border border-gold/40 bg-gold/30 px-2 py-0.5 text-gold uppercase tracking-wider">
                            Locked
                          </span>
                        )}
                        {p.joinedMidRound && (
                          <span className="text-xs rounded-full border border-white/30 bg-white/10 px-2 py-0.5 text-white/70 uppercase tracking-wider">
                            Next Round
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="font-display text-3xl text-gold tracking-wider">
                      {p.score}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {(!gameState?.players || gameState.players.length === 0) && (
              <div className="text-center py-8 text-white/40 text-sm uppercase tracking-wider">
                No players yet
              </div>
            )}
          </div>
        </div>

        {gameState?.phase === "judging" && gameState.guesses.length > 0 && (
          <div className="rounded-xl border border-gold/30 bg-black/30 p-6">
            <h3 className="font-display text-2xl text-gold uppercase tracking-wider mb-4 border-b border-white/10 pb-3">
              Guesses Submitted
            </h3>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {gameState.guesses.map((g) => (
                <div
                  key={g.id}
                  className="rounded-lg border border-white/10 bg-white/5 px-4 py-3"
                >
                  <div className="font-semibold text-gold text-sm mb-1">
                    {g.playerName}
                  </div>
                  <div className="text-white/90 text-lg">{g.text}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
